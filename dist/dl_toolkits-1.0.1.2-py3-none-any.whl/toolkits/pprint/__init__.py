"""
The `toolkits.pprint` module implements pretty print of the results.
"""

from .pred import pred

__all__ = [
    "pred",
]