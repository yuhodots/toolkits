"""
The `toolkits.viz` module implements data visualization techniques.
"""

from .tsne import tsne

__all__ = [
    "tsne",
]