"""
The `toolkits.pprint` module implements pretty print of the results.
"""

from .pred_summary import pred_summary

__all__ = [
    "pred_summary",
]